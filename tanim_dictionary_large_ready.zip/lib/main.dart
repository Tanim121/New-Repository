// Tanim Dictionary - Flutter app (main.dart)
// Offline Bangla <-> English dictionary (Large)
// App name: Tanim Dictionary (no extra icon, only name shown)
import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DictionaryDatabase.instance.database;
  runApp(TanimDictionaryApp());
}

class TanimDictionaryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tanim Dictionary',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system, // Auto (light/dark)
      home: SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 700), () {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomePage()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Tanim Dictionary', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('Offline Bangla ↔ English', style: TextStyle(fontSize: 16)),
          SizedBox(height: 16),
          Text('Made by Tanim', style: TextStyle(fontSize: 12, color: Colors.grey)),
        ]),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _searchController = TextEditingController();
  String _direction = 'bn_en'; // 'bn_en' or 'en_bn'
  List<WordItem> _results = [];
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  _onSearchChanged() {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), () async {
      final q = _searchController.text.trim();
      if (q.isEmpty) {
        setState(() => _results = []);
        return;
      }
      final results = await DictionaryDatabase.instance.search(q, _direction);
      setState(() => _results = results);
    });
  }

  Widget _buildResultTile(WordItem item) {
    return ListTile(
      title: Text(item.word),
      subtitle: Text(item.meaning),
      leading: Icon(Icons.book),
      onTap: () async {
        await showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text(item.word),
            content: SingleChildScrollView(child: Text(item.meaning)),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: Text('Close'))
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tanim Dictionary'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              setState(() {
                _direction = v;
                _onSearchChanged();
              });
            },
            itemBuilder: (ctx) => [
              PopupMenuItem(value: 'bn_en', child: Text('Bangla → English')),
              PopupMenuItem(value: 'en_bn', child: Text('English → Bangla')),
            ],
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12.0),
              child: Center(child: Text(_direction == 'bn_en' ? 'BN→EN' : 'EN→BN')),
            ),
          )
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: _direction == 'bn_en' ? 'Bangla word khujean...' : 'English word khujean...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                ),
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _onSearchChanged(),
              ),
            ),
            Expanded(
              child: _results.isEmpty
                  ? Center(child: Text('Search results will appear here'))
                  : ListView.builder(
                      itemCount: _results.length,
                      itemBuilder: (_, i) => _buildResultTile(_results[i]),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

// Data model
class WordItem {
  final int? id;
  final String word;
  final String meaning;
  final String lang; // 'bn' or 'en'

  WordItem({this.id, required this.word, required this.meaning, required this.lang});

  factory WordItem.fromMap(Map<String, dynamic> m) => WordItem(
        id: m['id'] as int?,
        word: m['word'] as String,
        meaning: m['meaning'] as String,
        lang: m['lang'] as String,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'word': word,
        'meaning': meaning,
        'lang': lang,
      };
}

// Database helper (singleton)
class DictionaryDatabase {
  DictionaryDatabase._privateConstructor();
  static final DictionaryDatabase instance = DictionaryDatabase._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasesPath = await getDatabasesPath();
    final path = join(databasesPath, 'tanim_dictionary.db');

    // If DB already exists, open it. Otherwise create and populate from assets.
    return await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE words(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          word TEXT,
          meaning TEXT,
          lang TEXT
        );
      ''');

    // Load initial data from assets/words.json
    final jsonStr = await rootBundle.loadString('assets/words.json');
    final List<dynamic> data = json.decode(jsonStr);
    final batch = db.batch();
    for (final entry in data) {
      batch.insert('words', {
        'word': entry['word'],
        'meaning': entry['meaning'],
        'lang': entry['lang'],
      });
    }
    await batch.commit(noResult: true);
    });
  }

  Future<List<WordItem>> search(String q, String direction) async {
    final db = await database;
    final normalized = q.toLowerCase();
    if (direction == 'bn_en') {
      final rows = await db.query(
        'words',
        where: 'lang = ? AND word LIKE ?',
        whereArgs: ['bn', '%$normalized%'],
        orderBy: 'word COLLATE NOCASE',
        limit: 200,
      );
      return rows.map((r) => WordItem.fromMap(r)).toList();
    } else {
      final rows = await db.query(
        'words',
        where: 'lang = ? AND word LIKE ?',
        whereArgs: ['en', '%$normalized%'],
        orderBy: 'word COLLATE NOCASE',
        limit: 200,
      );
      return rows.map((r) => WordItem.fromMap(r)).toList();
    }
  }

  Future<int> insertWord(WordItem item) async {
    final db = await database;
    return await db.insert('words', item.toMap());
  }
}
